<div class="wap_tintuc">
	<div class="bao_tintuc">
		<div class="tintuc">
	    	<?php include _template."layout/tinnoibat.php";?>
		</div>

	  <div class="video">
	    	<?php include _template."layout/video.php";?>
		</div>

	  <div class="fanpage">
	  	  <?php include _template."layout/fanpage.php";?>
	  </div>
	    <div class="clear"></div>
	</div><!--.bao_tintuc-->
</div><!--.wap_tintuc-->
