<div align="right" style="left: -136px; width:400px; overflow:hidden; position: absolute; top: 400px;" id="divAdLeft">
	<div><div   class="bocuc" id="sanpham_hot">
		<style tyle="text/css">
			.sanpham_hot-left {width:204px;position:fixed;left:-204px;top:230px;transition:All 1.2s ease;z-index:99; background: #FFFFFF;}
			.sanpham_hot-left:hover {left:0px}
			.bg-left , .bg-right {float:left}
			.sanpham_hot-left .download-bg {margin:9px;padding:0px;color:#2ECCFA}
			.sanpham_hot-left .download-bg li {float:left;list-style:none;border-bottom:1px dotted #ccc;width:100%}
			.sanpham_hot-left .download-bg li:hover {background:#ececec}
			.sanpham_hot-left .download-bg li p {padding-left:15px;cursor:pointer;font-size:12px}
			.sanpham_hot-left .download-bg li .fa {padding-right:10px}
			.sanpham_hot-left .rotate {position:relative}
			.sanpham_hot-left .download-bg {background:#FFF}
			.sanpham_hot-left .title-bg {background: #FFBF00;color: #0101DF;font-weight: bold;transform: rotate(270deg);-webkit-transform: rotate(270deg);-moz-transform: rotate(270deg);font-size: 18px;position: absolute;height: 36px;width:253px;top: 96px;text-align: left;left: -105px;border-bottom-right-radius:5px;border-bottom-left-radius:16px}
			.sanpham_hot-left .title-bg p {margin:0px;padding:5px}
			.sanpham_hot-left .title-bg .fa {color: #FB8E1A;background-color: #FFF;border-radius: 50%;padding: 5px;width: 10px;height: 20px;display: inline-block;vertical-align: middle;margin: 0px 19px;text-align: center;margin-top:-5px}
		</style>
		<div class="sanpham_hot-left">
			<div class="">
				<div class="bg-left">
					<ul class="download-bg">
						<li><p><a href="http://hungvuongcoltd.com/san-pham/quat-tran-7/"><i class="fa fa-download"></i><span style="color: #006600;">Quạt ốp la phông</span></a></p></li>
						<li><p><a href="http://hungvuongcoltd.com/san-pham/may-lanh-di-dong-nakatomi-1/"><i class="fa fa-download"></i><span style="color: #006600;">Máy lạnh di động</span></a></p></li>
						<li><p><a
							href="http://hungvuongcoltd.com/san-pham/quat-hut-dang-tron-2/"><i class="fa fa-download"></i><span style="color: #006600;">Quạt hút dạng tròn</span></a></p></li>
							<li><p><a href="http://hungvuongcoltd.com/san-pham/quat-dung-cong-nghiep-5/"><i class="fa fa-download"></i><span style="color: #006600;">Quạt đứng công nghiệp</span></a></p></li>
							<li><p><a href="http://hungvuongcoltd.com/san-pham/composite-hua-yin-29/"><i class="fa fa-download"></i><span style="color: #006600;">Quạt hút Composite</span></a></p></li>
							<li><p><a href="http://hungvuongcoltd.com/chinh-sach-mua-hang/ve-chung-toi-10.html"><i class="fa fa-download"></i><span style="color: #006600;">Về chúng tôi</span></a></p></li>
							<div class="clear"></div>
						</ul>
					</div>
					<div class="bg-right rotate">
						<div class="title-bg"><p><i class="fa fa-rocket"></i>SẢN PHẨM HOT <?=date('Y',time())?></p></div> 
					</div>
				</div>
			</div>
