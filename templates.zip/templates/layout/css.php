<!-- <link href="css/default.css" type="text/css" rel="stylesheet" />
<link href="style.css" type="text/css" rel="stylesheet" />
<link href="media.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="css/slick.css"/>
<link rel="stylesheet" type="text/css" href="css/slick-theme.css"/>
<link href="css/css_jssor_slider.css" type="text/css" rel="stylesheet" />
<link href="fontawesome/fontawesome-all.css" type="text/css" rel="stylesheet" /> -->
<link rel="stylesheet" type="text/css" href="css/jquery.simplyscroll.css?v=1"/>
<link href="css/owl.carousel.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
<?php if($template != 'index') { ?>
	<link rel="stylesheet" href="css/jquery.fancybox.min.css">
	<link href="magiczoomplus/magiczoomplus.css" rel="stylesheet" type="text/css" media="screen"/>
<?php } ?>
<?php if($template=='product_detail'){ ?>
	<link rel="stylesheet" type="text/css" href="fotorama/fotorama.css">
<?php } ?>
<style type="text/css">
	.gh1{
		background: url(images/gh1.png) no-repeat center left;
    	padding-left: 35px !important;
	}
	.tinhtrang{
		    float: right;
		    margin-right: 50px;
		    border: 1px solid #7d1315;
		    color: #7d1315;
		    text-transform: uppercase;
		    font-style: normal;
		    padding: 1px 5px;
		    font-weight: bold;
	}
	li.gia .giacu{
		    color: #c27762;
		    margin-left: 10px;
		    text-decoration: line-through;
		    margin-right: 5px;
		    font-weight: 100;
		    font-size: 13px;
		    font-family: arial;
	}
	.sp_gia .giacu{margin-left: 10px;}
	.giam{color: #c27762;font-weight: 100; font-family: arial;font-size: 13px;}
	i.giacu { font-family: arial;  font-size: 13px;   color: #c27762;   text-decoration: line-through;font-style: normal;margin-left: 0px !important}
	.giams{text-decoration: none;font-size: 13px;font-style: normal;color: #c27762; font-family: arial; }
	.thongtin-sp .sp_gia span.giakm{}
	.thongtin-sp .sp_gia span.giacu{margin-left: 0px;}

	.gia i{font-style: normal;}
	.gia i.giams{}
	span.ads{display: block;}

	.fotorama__active .fotorama__img{
		
	}
	.fancybox-slide--html{
		padding: 0px !important;
	}
	.hello{
		    width: 100%;
    		height: 100%;
    		background: #000;
	}
	.hello #fixed_nav_foto{
		display: flex;
	}
	.video_for{
		
	}
	.fancybox-close-small{
	    z-index: 9999 !important;
	    color: #fff !important;
	}
	.fotorama__fullscreen-icon{
		display: none !important;
	}
	.close-overlay{display: none;}
</style>
