<script type='text/javascript' src='js/flags.js'></script>
<script type="text/javascript">
   function GoogleLanguageTranslatorInit() {
   new google.translate.TranslateElement({pageLanguage: 'vi', autoDisplay: false }, 'google_language_translator');}
        </script><script type="text/javascript" src="http://translate.google.com/translate_a/element.js?cb=GoogleLanguageTranslatorInit">
</script>

<style type="text/css">
	/*.goog-te-banner-frame{visibility:hidden !important;}*/
	#google_language_translator { width:auto !important; display: none; }
	.goog-te-gadget .goog-te-combo {margin: 4px 0px !important;}
	.goog-tooltip {display: none !important;}
	.goog-tooltip:hover {display: none !important;}
	.goog-text-highlight {background-color: transparent !important; border: none !important; box-shadow: none !important;
  .glt-clear { height:0px; clear:both; margin:0px; padding:0px; }
  .langCon{position:absolute; top:5px; right:10px; z-index:100;}
	#flags a {height: 20px; display: inline-block;}
</style>

<div class="langCon" style="position:absolute; top:5px; right:10px; z-index:100;">
    <div class="execphpwidget">
        <div id="flags">
            <a href="" onclick="doGoogleLanguageTranslator('vi|vi'); return false;" title="Việt Nam" class="flag vi"><img src="images/vi.png" border="0" /></a>
            <a href="" onclick="doGoogleLanguageTranslator('vi|en'); return false;" title="English" class="flag en"><img src="images/en.png" border="0" /></a>
        </div>
         <div id="google_language_translator"></div>
    </div>
</div>
