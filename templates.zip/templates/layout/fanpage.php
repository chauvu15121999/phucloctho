<div class="tieude2">Fanpage</div>
<?=lay_fanpage($company['fanpage'],380,350)?>