<div class="wap_thongtin clearfix">
    <div class="thongtin clearfix">
		<span><i class="fas fa-map-marker-alt"></i><?=$company['diachi']?></span>
		<span class="dienthoai"><i class="fas fa-phone-volume"></i><?=$company['dienthoai']?></span>
		<span class="email"><i class="far fa-envelope"></i><?=$company['email']?></span>
		<div class="mxh_top"><?=lay_mxh('mxh_top');?></div>
	</div>
</div>
