<div class="chats">
<?=$company['codethem3']?>
</div>