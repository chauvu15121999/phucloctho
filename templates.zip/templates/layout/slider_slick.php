<div id="slider_slick">
	<?=lay_slider('slider')?>
</div>